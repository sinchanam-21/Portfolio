import React, { useState } from 'react';
import { usePortfolio } from '../context/PortfolioContext';
import { Lock, Unlock, KeyRound, AlertCircle, X, ShieldCheck } from 'lucide-react';

export const OwnerAuthModal: React.FC = () => {
  const { isAuthModalOpen, setIsAuthModalOpen, unlockOwner, setIsEditModalOpen } = usePortfolio();
  const [passcode, setPasscode] = useState('');
  const [error, setError] = useState('');
  const [showPasscode, setShowPasscode] = useState(false);

  if (!isAuthModalOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!passcode.trim()) {
      setError('Please enter your owner passcode.');
      return;
    }

    const success = unlockOwner(passcode);
    if (success) {
      setPasscode('');
      setError('');
      setIsAuthModalOpen(false);
      setIsEditModalOpen(true);
    } else {
      setError('Incorrect passcode. Please check your credentials.');
    }
  };

  const handleQuickUnlock = () => {
    unlockOwner('21005');
    setIsAuthModalOpen(false);
    setIsEditModalOpen(true);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#0F0F0F] border border-[#333] w-full max-w-md rounded-lg shadow-2xl p-6 sm:p-7 relative overflow-hidden">
        
        {/* Close Button */}
        <button
          onClick={() => {
            setIsAuthModalOpen(false);
            setError('');
            setPasscode('');
          }}
          className="absolute top-4 right-4 text-[#888] hover:text-white p-1 rounded hover:bg-[#1A1A1A] transition cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 mb-5">
          <div className="w-10 h-10 rounded bg-[#161616] border border-[#C5A059]/40 flex items-center justify-center text-[#C5A059]">
            <KeyRound className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-serif text-[#F2F2F2]">Owner Authentication</h3>
            <p className="text-[11px] font-mono uppercase tracking-wider text-[#C5A059]">Restricted to Sinchana M</p>
          </div>
        </div>

        <p className="text-xs text-[#999] mb-5 leading-relaxed font-sans">
          This portfolio is protected against unauthorized edits. Enter your owner passcode to unlock real-time content editing, project management, and inquiry message review.
        </p>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-[11px] uppercase tracking-wider font-semibold text-[#BBB] mb-1.5">
              Owner Passcode / PIN
            </label>
            <div className="relative">
              <input
                type={showPasscode ? 'text' : 'password'}
                value={passcode}
                onChange={(e) => {
                  setPasscode(e.target.value);
                  if (error) setError('');
                }}
                placeholder="Enter passcode (e.g. 21005)"
                autoFocus
                className="w-full px-4 py-2.5 rounded bg-[#0A0A0A] border border-[#2A2A2A] focus:border-[#C5A059] text-xs text-[#EEE] placeholder-[#555] focus:outline-none transition pr-16"
              />
              <button
                type="button"
                onClick={() => setShowPasscode(!showPasscode)}
                className="absolute right-3 top-2.5 text-xs text-[#777] hover:text-[#BBB] cursor-pointer"
              >
                {showPasscode ? 'Hide' : 'Show'}
              </button>
            </div>
            {error && (
              <p className="text-xs text-rose-400 mt-1.5 flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                <span>{error}</span>
              </p>
            )}
          </div>

          <div className="bg-[#141414] border border-[#262626] rounded p-3 flex items-start gap-2.5 text-[11px] text-[#888]">
            <ShieldCheck className="w-4 h-4 text-[#C5A059] shrink-0 mt-0.5" />
            <div>
              <span>Default owner PIN is </span>
              <button
                type="button"
                onClick={handleQuickUnlock}
                className="font-mono font-bold text-[#C5A059] underline hover:text-[#E2C785] cursor-pointer"
              >
                21005
              </button>
              <span> (configured for Sinchana M). You can change this in the Owner Settings.</span>
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-2.5 rounded text-xs font-semibold uppercase tracking-wider border border-[#C5A059] bg-[#C5A059] hover:bg-[#A88243] text-black transition flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-black/50"
          >
            <Unlock className="w-3.5 h-3.5" />
            <span>Unlock Edit Mode</span>
          </button>
        </form>

      </div>
    </div>
  );
};
